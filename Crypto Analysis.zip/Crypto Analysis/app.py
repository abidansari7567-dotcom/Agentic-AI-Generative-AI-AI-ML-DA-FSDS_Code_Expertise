import streamlit as st
import pandas as pd
import numpy as np
import pickle
from sklearn.ensemble import RandomForestRegressor

model_path = 'random_forest_model.pkl'
with open(model_path, 'rb') as file:
    model_rf = pickle.load(file)
    
def predict_btc_price(input_data):
    prediction = model_rf.predict(input_data)
    return prediction[0]

def main():
    st.title('Predict BTC Close Price')
    
    st.sidebar.title('Input Features')
    
    usdt_close = st.sidebar.number_input('USDT Close Price', min_value=0.0, format="%.2f")
    usdt_volume = st.sidebar.number_input('USDT Volume', min_value=0.0, format="%.2f")
    bnb_close = st.sidebar.number_input('BNB Close Price', min_value=0.0, format="%.2f")
    bnb_volume = st.sidebar.number_input('BNB Volume', min_value=0.0, format="%.2f")
    
    input_data = pd.DataFrame({
        'USDT_Close': [usdt_close],
        'USDT_Volume': [usdt_volume],
        'BNB_Close': [bnb_close],
        'BNB_Volume': [bnb_volume],
    })
    
    
    if st.button('Predict BTC Close Price'):
        predicted_price = predict_btc_price(input_data) 
        st.write('Predicted BTC Close Price', predicted_price)
        
if __name__ == '__main__':
    main()